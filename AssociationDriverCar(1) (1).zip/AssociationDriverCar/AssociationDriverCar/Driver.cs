﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssociationExample_DriverCar_
{
    class Driver
    {
        private string name;
        private string drivingLicenseNo;
        private string address;

        private Car carOwnedByDriver; // This attribute links driver to his/her car

        public Driver(string newName, string newLicenseNo, string newAddress)
        {
            name = newName;
            drivingLicenseNo = newLicenseNo;
            address = newAddress;

        }

        // get and set operations to be done by students

        public void associateCar(Car driverCar)
        {
            carOwnedByDriver = driverCar;
        }

        public Car getCar()
        {
            return carOwnedByDriver;
        }
    }
}
