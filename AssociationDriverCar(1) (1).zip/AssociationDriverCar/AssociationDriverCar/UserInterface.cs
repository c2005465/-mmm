﻿using AssociationExample_DriverCar_;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssociationDriverCar
{
    public partial class UserInterface : Form
    {
        Driver aDriver;
        Car aCar;
        public UserInterface()
        {
            InitializeComponent();

            // we initialise objects before first use

            aCar = new Car("YN51 ZNV", "VW", "Golf");
            aDriver = new Driver("LicenseNo 1", "Mehmet", "Sheffield");
        }

        private void AssignCarButton_Click(object sender, EventArgs e)
        {
            aDriver.associateCar(aCar); // Car is linked to driver
        }

        private void GetCarButton_Click(object sender, EventArgs e)
        {
            Car driverCar;

            driverCar = aDriver.getCar(); // we get the car associated with the driver

            RegTextBox.Text = driverCar.getRegistrationPlate();
            MakeTextBox.Text = driverCar.getMake();
            ModelTextBox.Text = driverCar.getModel();
        }
    }
}
