﻿namespace AssociationDriverCar
{
    partial class UserInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AssignCarButton = new System.Windows.Forms.Button();
            this.GetCarButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.RegTextBox = new System.Windows.Forms.TextBox();
            this.MakeTextBox = new System.Windows.Forms.TextBox();
            this.ModelTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // AssignCarButton
            // 
            this.AssignCarButton.Location = new System.Drawing.Point(33, 34);
            this.AssignCarButton.Name = "AssignCarButton";
            this.AssignCarButton.Size = new System.Drawing.Size(182, 84);
            this.AssignCarButton.TabIndex = 0;
            this.AssignCarButton.Text = "Assign Car to Driver";
            this.AssignCarButton.UseVisualStyleBackColor = true;
            this.AssignCarButton.Click += new System.EventHandler(this.AssignCarButton_Click);
            // 
            // GetCarButton
            // 
            this.GetCarButton.Location = new System.Drawing.Point(35, 177);
            this.GetCarButton.Name = "GetCarButton";
            this.GetCarButton.Size = new System.Drawing.Size(179, 73);
            this.GetCarButton.TabIndex = 1;
            this.GetCarButton.Text = "Get Car Details";
            this.GetCarButton.UseVisualStyleBackColor = true;
            this.GetCarButton.Click += new System.EventHandler(this.GetCarButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(472, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Car Details";
            // 
            // RegTextBox
            // 
            this.RegTextBox.Location = new System.Drawing.Point(471, 114);
            this.RegTextBox.Name = "RegTextBox";
            this.RegTextBox.Size = new System.Drawing.Size(230, 26);
            this.RegTextBox.TabIndex = 3;
            // 
            // MakeTextBox
            // 
            this.MakeTextBox.Location = new System.Drawing.Point(473, 185);
            this.MakeTextBox.Name = "MakeTextBox";
            this.MakeTextBox.Size = new System.Drawing.Size(227, 26);
            this.MakeTextBox.TabIndex = 4;
            // 
            // ModelTextBox
            // 
            this.ModelTextBox.Location = new System.Drawing.Point(473, 249);
            this.ModelTextBox.Name = "ModelTextBox";
            this.ModelTextBox.Size = new System.Drawing.Size(226, 26);
            this.ModelTextBox.TabIndex = 5;
            // 
            // UserInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ModelTextBox);
            this.Controls.Add(this.MakeTextBox);
            this.Controls.Add(this.RegTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GetCarButton);
            this.Controls.Add(this.AssignCarButton);
            this.Name = "UserInterface";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AssignCarButton;
        private System.Windows.Forms.Button GetCarButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox RegTextBox;
        private System.Windows.Forms.TextBox MakeTextBox;
        private System.Windows.Forms.TextBox ModelTextBox;
    }
}

