﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssociationExample_DriverCar_
{
    class Car
    {
        private string registrationPlate;
        private string make;
        private string model;

        public Car(string reg, string newMake, string newModel)
        {
            registrationPlate = reg;
            make = newMake;
            model = newModel;
        }

        public string getRegistrationPlate()
        {
            return registrationPlate;
        }

        public string getMake()
        {
            return make;
        }

        public string getModel()
        {
            return model;
        }

        // set operation to be done by students
    }
}
